var swiper = new Swiper (".mySwiper-1",{
    slidesPerView:1,
    spaceBetween: 30,
    loop:true,
    pagination: {
        el: ".swiper-pagination",
        clickable: true,
    },
    navigation: {
        nextEl:".swiper-button-next",
        prevEl: ".swiper-button-prev",
    }
});


var swiper = new Swiper (".mySwiper-2",{
    slidesPerView:3,
    spaceBetween: 20,
    loop:true,
    loopFillGroupWithBlank:true,
    navigation: {
        nextEl:".swiper-button-next",
        prevEl: ".swiper-button-prev",
    },
    breakpoints : {
        0:{
            slidesPerView:1,
        },
        520:{
            slidesPerView:2,
        },
        950:{
            slidesPerView:3,
        }
    }
});



function formu() {
    var nombre = document.getElementById("nombre").value;
    var telefono = document.getElementById("Telefono").value;
    var correo = document.getElementById("correo").value;
    var informa = document.querySelector('input[name="informa"]:checked').value;

    var preferencias = [];
    var checkboxes = document.querySelectorAll('input[type="checkbox"]:checked');
    checkboxes.forEach(function(checkbox) {
        preferencias.push(checkbox.name);
    });

    var mensaje = "Nombre: " + nombre + "\n";
    mensaje += "Teléfono: " + telefono + "\n";
    mensaje += "Correo Electrónico: " + correo + "\n";
    mensaje += "Desea recibir notificaciones: " + informa + "\n";
    mensaje += "Preferencias: " + preferencias.join(", ") + "\n";

    // Muestra el mensaje emergente con opciones Aceptar y Rechazar
    var confirmacion = confirm("¿Está seguro de enviar esta información?\n\n" + mensaje);

    if (confirmacion) {
        alert("¡Información enviada con éxito!");
        // Aquí puedes agregar código para enviar los datos, almacenarlos en una base de datos, etc.
    } else {
        alert("La información no fue enviada.");
    }
}
